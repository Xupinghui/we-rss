import { FC, useMemo } from 'react';
import {
  Table,
  TableHeader,
  TableColumn,
  TableBody,
  TableRow,
  TableCell,
  getKeyValue,
  Button,
  Spinner,
  Link,
  Card,
} from '@nextui-org/react';
import { trpc } from '@web/utils/trpc';
import dayjs from 'dayjs';
import { useParams } from 'react-router-dom';

const ArticleList: FC = () => {
  const { id } = useParams();

  const mpId = id || '';

  const { data, fetchNextPage, isLoading, hasNextPage } =
    trpc.article.list.useInfiniteQuery(
      {
        limit: 20,
        mpId: mpId,
      },
      {
        getNextPageParam: (lastPage) => lastPage.nextCursor,
      },
    );

  const items = useMemo(() => {
    const items = data
      ? data.pages.reduce((acc, page) => [...acc, ...page.items], [] as any[])
      : [];

    return items;
  }, [data]);

  return (
    <div className="px-4 pb-4">
      <Card className="shadow-sm border border-gray-200 dark:border-gray-800 p-0 overflow-hidden">
        <Table
          aria-label="文章列表"
          removeWrapper
          isHeaderSticky
          classNames={{
            base: "h-full",
            table: "min-h-[420px]",
            th: "bg-gray-50 dark:bg-gray-900 text-gray-600 dark:text-gray-400 font-medium",
            tr: "hover:bg-gray-50 dark:hover:bg-gray-900 transition-colors",
          }}
          bottomContent={
            hasNextPage && !isLoading ? (
              <div className="flex w-full justify-center py-3">
                <Button
                  isDisabled={isLoading}
                  variant="flat"
                  color="primary"
                  className="px-8"
                  onPress={() => {
                    fetchNextPage();
                  }}
                >
                  {isLoading ? <Spinner color="white" size="sm" /> : null}
                  加载更多文章
                </Button>
              </div>
            ) : null
          }
        >
          <TableHeader>
            <TableColumn key="title">标题</TableColumn>
            <TableColumn width={180} key="publishTime">
              发布时间
            </TableColumn>
          </TableHeader>
          <TableBody
            isLoading={isLoading}
            emptyContent={
              <div className="py-10 text-center">
                <p className="text-gray-500 mb-3">暂无文章数据</p>
                <p className="text-xs text-gray-400">请添加公众号后查看</p>
              </div>
            }
            items={items || []}
            loadingContent={<Spinner color="primary" />}
          >
            {(item) => (
              <TableRow key={item.id}>
                {(columnKey) => {
                  let value = getKeyValue(item, columnKey);

                  if (columnKey === 'publishTime') {
                    value = dayjs(value * 1e3).format('YYYY-MM-DD HH:mm');
                    return <TableCell className="text-gray-500 text-sm">{value}</TableCell>;
                  }

                  if (columnKey === 'title') {
                    return (
                      <TableCell>
                        <Link
                          className="visited:text-neutral-400 font-medium hover:text-primary transition-colors"
                          isBlock
                          showAnchorIcon
                          color="foreground"
                          target="_blank"
                          href={`https://mp.weixin.qq.com/s/${item.id}`}
                        >
                          {value}
                        </Link>
                      </TableCell>
                    );
                  }
                  return <TableCell>{value}</TableCell>;
                }}
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
};

export default ArticleList;
